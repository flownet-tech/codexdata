# Codex Pass tokens

Shared semantic colors, typography, control geometry and motion for all Codex Pass applications. Import theme.css before components. Apply .dark or data-mode="dark" to the document root. docs.css is the static documentation layout using the same tokens, with no JavaScript or React dependency.
